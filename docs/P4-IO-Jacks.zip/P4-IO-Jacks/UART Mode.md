---
tags:
  - p4-io-jacks
  - uart
  - uart-mode
erstellt: 2026-06-17
status: beschreibung
---

# IO-Jack — UART Mode

> IO-Jack im UART-Modus — serielle Schnittstelle mit Konfiguration über `cfg` und Datentransfer über `uart`.

---

## Funktionsweise

Im **UART Mode** arbeitet ein IO-Jack als serielle Schnittstelle mit zwei Subtopics:

| Subtopic | Zweck |
|---|---|
| **`cfg`** | UART-Einstellungen setzen |
| **`uart`** | rohe UART-Datenbytes senden / empfangen |

---

## Konfiguration (`cfg`)

Die Schnittstelle wird vor dem Datentransfer mit fünf Parametern konfiguriert. Kurzform: `Baudrate-Datenbits-Parität-Stoppbits` (N = keine, E = gerade, O = ungerade):

| Konfiguration | Baudrate | Datenbits | Parität | Stoppbits | RS485 |
|---|--:|:--:|---|:--:|:--:|
| **Standard** · `115200-8-N-1` | 115.200 | 8 | keine | 1 | aus |
| **Klassisch** · `9600-8-N-1` | 9.600 | 8 | keine | 1 | aus |
| **7-Bit, gerade** · `9600-7-E-1` | 9.600 | 7 | gerade | 1 | aus |
| **RS485-Bus** · `500000-8-N-1` | 500.000 | 8 | keine | 1 | **an** |
| **High-Speed** · `3000000-8-N-1` | 3.000.000 | 8 | keine | 1 | aus |

---

## Parameter

**Baudrate**

| Baudrate (Bit/s) | Konstante | Code |
|---:|---|:--:|
| 300 | `UartBaud300` | `0x00` |
| 600 | `UartBaud600` | `0x01` |
| 1.200 | `UartBaud1200` | `0x02` |
| 2.400 | `UartBaud2400` | `0x03` |
| 4.800 | `UartBaud4800` | `0x04` |
| 9.600 | `UartBaud9600` | `0x05` |
| 19.200 | `UartBaud19200` | `0x06` |
| 38.400 | `UartBaud38400` | `0x07` |
| 115.200 | `UartBaud115200` | `0x08` |
| 230.400 | `UartBaud230400` | `0x09` |
| 500.000 | `UartBaud500000` | `0x0A` |
| 1.000.000 | `UartBaud1000000` | `0x0B` |
| 3.000.000 | `UartBaud3000000` | `0x0C` |
| 5.000.000 | `UartBaud5000000` | `0x0D` |

**Datenbits**

| Datenbits | Konstante | Wert |
|:--:|---|:--:|
| 7 | `UartData7` | `0x2000` |
| **8** | `UartData8` | `0x0000` |
| 9 | `UartData9` | `0x1000` |

**Parität**

| Parität | Konstante | Wert |
|---|---|:--:|
| keine | `UartParityNone` | `0x0000` |
| gerade | `UartParityEven` | `0x0400` |
| ungerade | `UartParityOdd` | `0x0800` |

**Stoppbits**

| Stoppbits | Konstante | Wert |
|:--:|---|:--:|
| 1 | `UartStopbits1` | `0x0000` |
| 1,5 | `UartStopbits15` | `0x0100` |
| 2 | `UartStopbits2` | `0x0200` |

**RS485**

| RS485 | Konstante |
|---|---|
| aus | *(Standard)* |
| an | `UartRS485` |

---

## 16-Bit-Konfigurationswort

Die Konfiguration wird als **ein 16-Bit-Wort** über `cfg` übertragen — zusammengesetzt durch **bitweise ODER-Verknüpfung** der Feldwerte:

| Bits | Feld | Werte |
|:--:|---|---|
| **15** | RS485 | aus `0x0000` · an `0x8000` |
| **12–14** | Datenbits | 8 `0x0000` · 9 `0x1000` · 7 `0x2000` |
| **10–11** | Parität | keine `0x0000` · gerade `0x0400` · ungerade `0x0800` |
| **8–9** | Stoppbits | 1 `0x0000` · 1,5 `0x0100` · 2 `0x0200` |
| **0–7** | Baudrate | Code aus obiger Tabelle |

**Beispiele:**

| Konfiguration | = Konfigwort |
|---|:--:|
| `115200-8-N-1` | **`0x0008`** |
| `9600-8-N-1` | **`0x0005`** |
| `9600-7-E-1` | **`0x2405`** |
| `500000-8-N-1` (RS485) | **`0x800A`** |
| `3000000-8-N-1` | **`0x000C`** |

---

## Querverweise

- Transport & Subtopics: [[MQTT & NATS]]
- Übersicht: [[P4-IO-Jacks Interfaces]]
