---
tags:
  - p4-io-jacks
  - gpio
  - port-mode
erstellt: 2026-06-17
status: beschreibung
---

# IO-Jack — PORT Mode

> IO-Jack im PORT-Modus – digitale Ein-/Ausgabe von 4 Bit.

---

## Funktionsweise

Im **PORT Mode** liest und schreibt ein IO-Jack **4 Bit** (Pin3 · Pin2 · Pin1 · Pin0).

Jedes Kommando ist **ein einziges, zusammengesetztes Byte**: Bit 7 = fester **Marker** `0`, Bits 6–4 = **Kommando** (C2 C1 C0), Bits 3–0 = **Daten** (Pin3…Pin0):

| Bit-Position | 7 | 6 | 5 | 4 | 3 | 2 | 1 | 0 |
|---|:--:|:--:|:--:|:--:|:--:|:--:|:--:|:--:|
| **Feld** | Marker | C2 | C1 | C0 | **Pin3** | **Pin2** | **Pin1** | **Pin0** |
| | `0` | *Kommando* | *Kommando* | *Kommando* | *Daten* | *Daten* | *Daten* | *Daten* |

Daraus ergeben sich die drei gezeigten Operationen und die Quittung – jeweils **als ein Byte**:

| Operation | 7 | 6 | 5 | 4 | 3 | 2 | 1 | 0 | = Byte |
|---|:--:|:--:|:--:|:--:|:--:|:--:|:--:|:--:|:--|
| **Write** – 4 Bit schreiben | `0` | `0` | `0` | `0` | P3 | P2 | P1 | P0 | `0000 PPPP` |
| **Read** – Leseanforderung | `0` | `0` | `0` | `1` | f | f | f | f | `0001 ffff` |
| **Read-Antwort** – 4 Bit gelesen | `0` | `0` | `0` | `1` | P3 | P2 | P1 | P0 | `0001 PPPP` |
| **Return Code** – Quittung (nach Write) | `0` | `1` | `1` | `1` | `0` | `0` | `0` | `0` | `0x70` = No Error |

- **P3…P0** = Zustand von Pin3…Pin0 (Daten-Nibble, `D3…D0`)
- **f** = **Read-Frequencies** (Daten-Nibble bei Read): `0` = einmalig, `1–15` = Sekunden, `>16` = Millisekunden
- Kommandocodes: `000` = Write/Value, `001` = Read, `111` = Return Code

---

## Befehlsdetails

Alle drei Operationen folgen dem 4-Bit-Data-Frame `0CCCDDDD` (1 Byte).

### Write — Read/Write Value (Code 0)

```
0 CCC DDDD  =  0 000 <Pin3 Pin2 Pin1 Pin0>
```

- `CCC = 000` → Kommando **0 (Read/Write Value)**
- `DDDD` = die 4 Pin-Zustände (PAD-Daten)

### Read — Read-Command (Code 1)

```
0 CCC DDDD  =  0 001 <Read-Frequencies>
```

- `CCC = 001` → Kommando **1 (Read-Command)**
- `DDDD` = **Read-Frequencies**: `0` = einmalig, `1–15` = Sekunden, `>16` = Millisekunden (periodisches Lesen)
- Die **Antwort** nutzt denselben Read-Code `001` mit den 4 gelesenen Bit im Datennibble → `0001 PPPP`.

### Return Code (Code 7)

```
0 CCC DDDD  =  0 111 0000  =  0x70   → No Error
```

- `CCC = 111` → Kommando **7 (Return Code)**
- `DDDD = 0000` → Error-Code **0 = No Error**

| Return Code (Byte) | Bedeutung |
|:--:|---|
| `0x70` | No Error |
| `0x71` | Bad Request |
| `0x72` | Not Found |
| `0x73` | Request Timeout |

### Mehr als 4 Pins

Der 4-Bit-Frame adressiert 4 PADs. Für breitere Ports werden dieselben Befehle in **8/16/32-Bit-Frames** verwendet (PAD-Maske entsprechend 8/16/32 Bit).

---

## Querverweise

- Übersicht: [[P4-IO-Jacks Interfaces]]
- Transport: [[MQTT & NATS]]
